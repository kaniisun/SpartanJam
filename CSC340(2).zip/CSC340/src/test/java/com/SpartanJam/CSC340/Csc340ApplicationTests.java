package com.SpartanJam.CSC340;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Csc340ApplicationTests {

	@Test
	void contextLoads() {
	}

}
